
fetch("students.json")
.then(function(response){
	return response.json();
})
.then(function(students){
	let placeholder = document.querySelector("#data-output");
	let out = "";
	for(let product of students){
		out += `
			<tr>
			
				<td>${product.name}</td>
				<td>${product.branch}</td>
				<td>${product.dob}</td>

			</tr>
		`;
	}

	placeholder.innerHTML = out;
});
// .then(function(students){
// 	let placeholder = document.querySelector("#data-output");
// 	let out = "";
// 	for(let product of students){
// 		out += `
// 			<tr>
// 				// <td> <img src='${product.image}'> </td>
// 				<td>${product.name}</td>
// 				<td>${product.branch}</td>
// 				<td>${product.dob}</td>
// 				<td>${product.productCode}</td>
// 			</tr>
// 		`;
// 	}

// 	placeholder.innerHTML = out;
// });




function myfun(){
	alert("hello dude")
	// score = "hello";
    // document.querySelector("#scoreval").textContent=score;
}